if (!Accounts.github) {
  Accounts.github = {};
}
