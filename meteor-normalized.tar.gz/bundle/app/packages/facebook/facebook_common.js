if (typeof Facebook === 'undefined') {
  Facebook = {};
}
