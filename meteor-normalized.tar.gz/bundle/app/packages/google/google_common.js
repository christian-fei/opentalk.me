if (typeof Google === 'undefined') {
  Google = {};
}
