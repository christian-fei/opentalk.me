(function(){Messages = new Meteor.Collection('Messages');
OnlineUsers = new Meteor.Collection('OnlineUsers');

})();
